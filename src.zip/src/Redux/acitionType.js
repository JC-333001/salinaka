// 添加至购物车指令
export let addToCarts = "addToCarts";
// 从购物车移除指令
export let removeFromCarts = "aremoveFromCarts";
//  增加商品的数量
export let increaseQuantitys = "increaseQuantitys";
// 减少商品的数量
export let decreaseQuantitys = "decreaseQuantitys";
// 清空购物车
export let clearCarts = "clearCart";
// 删除该商品
export let removeCarts = "removeCart";
// 过滤商品
export let filterShops = "filterShop";
// 重制商店
export let resetShops = "resetShop";
