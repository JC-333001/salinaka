//  Store使用
// 从redux引入createStore()  负责处理reducer
import {createStore} from 'redux'
// 引入reducer函数
import rootReducer from './reducer'
// 将Reducer里面的数据保存在store
let store = createStore(rootReducer)
// 将store暴露出来，方便其他的组件访问store里面的数据
export default store