import allDatas from "../data/data_origin";
// reducers 处理数据  通过action来进行处理
import {
  addToCarts,
  increaseQuantitys,
  decreaseQuantitys,
  removeCarts,
  clearCarts,
  filterShops,
  resetShops,
} from "./acitionType";
let datas = allDatas();
//  购物车里面的数据以及存放在store里面的数据
let product = {
  // 所有的数据，需要存放在store里面
  products: datas,
  // 购物车里面的数据
  cartItems: [],
  // 过滤后的shop里的数据
  shopItems: datas,
};
// 定义reducer函数,函数里包含了两个参数 1.state   2.action
let rootReducer = (state = product, action) => {
  //    根据不同的水果名字弹出不同的价格
  switch (action.type) {
    case addToCarts:
      // 数据处理
      // ?
      // 判断购物车里面是否有该商品

      let { mycolor, myparameter, mysize } = action.payload;
      let { id, name, brand, desc, price, img, parameter, category } =
        state.products.find((product) => product.parameter == myparameter);
      console.log("in reduceer", action.payload, myparameter);
      // boolean
      let existingItem = state.cartItems.find(
        (item) =>
          item.parameter == parameter &&
          item.color == mycolor &&
          item.size == mysize
      );

      if (existingItem) {
        return {
          ...state,
          cartItems: state.cartItems.map((item) =>
            item.parameter == parameter &&
            item.color == mycolor &&
            item.size == mysize
              ? { ...item, quantity: item.quantity + 1 }
              : item
          ),
        };
      } else {
        return {
          ...state,
          cartItems: [
            ...state.cartItems,
            {
              id,
              name,
              brand,
              desc,
              price,
              img,
              parameter,
              category,
              size: mysize,
              color: mycolor,
              quantity: 1,
            },
          ],
        };
      }
    case increaseQuantitys:
      return {
        ...state,
        cartItems: state.cartItems.map((item) =>
          item.parameter == action.payload
            ? { ...item, quantity: item.quantity + 1 }
            : item
        ),
      };
    case decreaseQuantitys:
      if (
        state.cartItems.find((item) => item.parameter == action.payload)
          .quantity == 1
      ) {
        return {
          ...state,
          cartItems: state.cartItems.filter(
            (item) => item.parameter !== action.payload
          ),
        };
      } else {
        return {
          ...state,
          cartItems: state.cartItems.map((item) =>
            item.parameter == action.payload
              ? { ...item, quantity: item.quantity - 1 }
              : item
          ),
        };
      }

    case clearCarts:
      return {
        ...state,
        cartItems: [],
      };
    case removeCarts:
      console.log("remove", state.cartItems);
      return {
        ...state,
        cartItems: state.cartItems.filter(
          (item) => item.parameter !== action.payload
        ),
      };
    case resetShops:
      return {
        ...state,
        shopItems: datas,
      };
    case filterShops:
      // console.log("filter shops");
      // console.log(`payload = ${action.payload.priceRange}`);
      let { brandName, sortByType, priceRange } = action.payload;
      let filteredShop = state.shopItems.filter(
        (item) =>
          (brandName == "All Brands" || item.brand == brandName) &&
          item.price >= priceRange[0] &&
          item.price <= priceRange[1]
      );
      switch (sortByType) {
        case "Name Ascending A - Z":
          filteredShop.sort((a, b) => {
            const nameA = a.name.toUpperCase(); // ignore upper and lowercase
            const nameB = b.name.toUpperCase(); // ignore upper and lowercase
            if (nameA < nameB) {
              return -1;
            }
            if (nameA > nameB) {
              return 1;
            }
            // names must be equal
            return 0;
          });
          break;
        case "Name Descending Z - A":
          filteredShop.sort((a, b) => {
            const nameA = a.name.toUpperCase(); // ignore upper and lowercase
            const nameB = b.name.toUpperCase(); // ignore upper and lowercase
            if (nameA < nameB) {
              return 1;
            }
            if (nameA > nameB) {
              return -1;
            }
            // names must be equal
            return 0;
          });
          break;
        case "Price High - Low":
          filteredShop.sort((a, b) => {
            if (a.price < b.price) {
              return 1;
            }
            if (a.price > b.price) {
              return -1;
            }
            // names must be equal
            return 0;
          });
          break;
        case "Price Low - Hign":
          filteredShop.sort((a, b) => {
            if (a.price < b.price) {
              return -1;
            }
            if (a.price > b.price) {
              return 1;
            }
            // names must be equal
            return 0;
          });
          break;
        default:
          break;
      }
      return {
        ...state,
        shopItems: filteredShop,
      };
    default:
      return state;
  }
};
export default rootReducer;
