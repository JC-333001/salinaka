import React from "react";

export default function Account() {
  return (
    <div>
      <div className='account_header'>
        <div className='account_header_tab'>Account</div>
        <div className='account_header_tab'>My Wish List</div>
        <div className='account_header_tab'>Account</div>
      </div>
    </div>
  );
}
