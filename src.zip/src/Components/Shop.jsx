import React from "react";
import Footer from "./Footer";
import ShopProductCard from "./ShopProductCard";

export default function Shop() {
  return (
    <div className='content_container'>
      <div>
        <ShopProductCard></ShopProductCard>
      </div>
      <Footer></Footer>
    </div>
  );
}
