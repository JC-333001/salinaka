import { addToCart } from "../Redux/action";
import { removeCart } from "../Redux/action";

// export let handleAddToCart = (parameter) => {
//   setButtonState(false);
//   dispatch(addToCart(parameter));
// };
// export let handdleRemoveFromCart = (parameter) => {
//   setButtonState(true);
//   dispatch(removeCart(parameter));
// };

//return the btn state of a item
// export let getBtnState = (cart, parameter) => {
//   const hasThisItem = cart.find((item) => item.parameter == parameter);
//   console.log("This item was added before");
//   const [buttonState, setButtonState] = useState(hasThisItem ? false : true);
//   return [buttonState, setButtonState];
// };
